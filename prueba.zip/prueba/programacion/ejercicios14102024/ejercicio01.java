package ejercicios14102024;

public class ejercicio01 {
    public static void main (String[] args) {
    	//crear array
        int[] n = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        //crear bucle para imprimir
        for (int i = 0; i < n.length; i++) {
            System.out.println(n[i]);
        }
    }
}