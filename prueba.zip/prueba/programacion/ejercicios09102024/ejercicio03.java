package ejercicios09102024;

public class ejercicio03 {
	public static void main(String[] args) {
		for (int i=0; i <= 50; i=  i+2) {
			System.out.println(i);
		}
	}
}