package ejercicios09102024;
public class ejercicio01 {
	public static void main(String[] args) {
		System.out.println("Numeros del 1 al 100");
		for(int i = 0; i <= 100; i++) {
			System.out.println(i);
		}
	}
}
