package exceptions;

public class EdadInvalidaException extends Exception {
	public EdadInvalidaException(String msg){
		super(msg);
	}
}
