package ejercicios02102024;

public class ejercicio09 {
	public static void main (String[] agrs) {
		String nombre = "Juan";
		String apellido = "Villacorta";
		int edad = 19;
		System.out.println("Mi nombre es: "+ nombre + ", mi apellido: " + apellido + "y mi edad es " + edad);
	}
}
