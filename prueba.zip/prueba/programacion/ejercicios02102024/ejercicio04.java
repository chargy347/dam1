package ejercicios02102024;

public class ejercicio04 {
	public static void main (String[] args) {
		int cel = 35;
		int fah = (cel * 9/5) +32;
		System.out.println(cel + " grados Celsius son " + fah + " grados Fahrenheit.");
	}
}
