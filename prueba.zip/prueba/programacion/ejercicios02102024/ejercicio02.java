package ejercicios02102024;

public class ejercicio02 {
	public static void main(String[] args) {
		int n1 = 2;
		int n2 = 4;
		int suma = n1 + n2;
		System.out.println("la suma es: " + suma);
	}
}