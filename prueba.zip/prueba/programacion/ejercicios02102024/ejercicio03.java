package ejercicios02102024;

public class ejercicio03 {
	public static void main (String [] agrs) {
		int altura = 2;
		int base = 2;
		int area = base * altura;
		System.out.println("el area es: " + area);
	}
}
