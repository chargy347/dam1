package ejercicios02102024;

public class ejercicio05 {
	public static void main(String[] args) {
	double pi = 3.14;
	int radio = 3;
	double perimetro = 2*pi*radio;
	System.out.println("El perimetro del circulo es: " + perimetro);
	}
}