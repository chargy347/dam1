package ejercicios02102024;

public class ejercicio01 {
	public static void main(String[] args) {
		int alumnos = 20;
		double notaCorte = 6.2;
		String centro = "Teide";
		System.out.println(alumnos + notaCorte + centro);
	}
}
