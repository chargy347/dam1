package ejercicios02102024;

public class ejercicio07 {
	public static void main (String[] agrs) {
		int n1 = 3;
		int n2 = 4;
		int n3 = 7;
		double promedio = (n1+n2+n3)/3;
		System.out.println("El promedio de los numeros es: " + promedio);
	}
}
