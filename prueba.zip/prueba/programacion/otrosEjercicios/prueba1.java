package otrosEjercicios;
import java.util.Scanner;
import java.util.Arrays;
import java.util.List;

public class prueba1 {
	public static void main(String[] args) {
		//datos necesarios
		int num =  0;
		List<String> abecedario = Arrays.asList(
				"A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
				"K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
				"U", "V", "W", "X", "Y", "Z" );
		// Imprimir la lista del abecedario
		System.out.println(abecedario);
		
		//
	}
}