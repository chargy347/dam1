package ejercicios03102024;

public class ejercicio08 {

	public static void main(String []agrs) {
		int suma = 0;
		for(int i = 0; i <= 100; i=i+2) {
			suma += i; 
		}
		System.out.println("La suma de los números del 1 al 100 es: " + suma);
	}

}
