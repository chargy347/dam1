package ejercicios03102024;

public class ejercicios05 {
	public static void main(String []agrs) {
		int suma = 0;
		for(int i = 1; i <= 100; i++) {
			suma += i; 
		}
		System.out.println("La suma de los números del 1 al 100 es: " + suma);
	}
}
