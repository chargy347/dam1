package ejercicios03102024;
import java.util.Scanner;

public class ejercicio02 {
	public static void main (String[] agrs) {
        Scanner scanner = new Scanner(System.in);
		System.out.println("Ingresa un numero");
        int n1 = scanner.nextInt();
		System.out.println("Ingresa un numero2");
        int n2 = scanner.nextInt();
		System.out.println("Ingresa un numero3");
        int n3 = scanner.nextInt();
        
        
	}
}
