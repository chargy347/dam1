package ejercicios03102024;

public class ejercicio04 {
	public static void main(String[]agrs) {
		for(int i = 0;i <= 10;i++)
		    {
		      System.out.println(i);
		    }
	}
}
